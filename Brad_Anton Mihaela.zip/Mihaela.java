//*******************************************************************
// Welcome to CompileJava!
// If you experience any issues, please contact us ('More Info')  -->
//*******************************************************************

public class Mihaela {
  public static void main(String[] args) {
    char stea = '*';
    char line = '-'; 
    char linie = '|'; 
    char bara1 = '/'; 
    char bara2 = '\\';
    System.out.printf("%14c%n", stea);
    System.out.printf("%13c%2c%n", bara1, bara2);
    System.out.printf("%12c%2c%2c%n", bara1,stea, bara2);
    System.out.printf("%11c%2c%2c%2c%n", bara1, bara2, bara1, bara2);
    System.out.printf("%10c%2c%2c%2c%2c%n", bara1, stea, stea, stea, bara2);
    System.out.printf("%9c%2c%2c%2c%2c%2c%n", bara1, bara2, bara1,bara2, bara1,bara2);
    System.out.printf("%8c%2c%2c%2c%2c%2c%2c%n", bara1, stea, stea, stea, stea, stea, bara2);
    System.out.printf("%7c%2c%2c%2c%2c%2c%2c%2c%n", bara1, bara2, bara1,bara2, bara1,bara2, bara1, bara2);
    System.out.printf("%6c%2c%2c%2c%2c%2c%2c%2c%2c%n", bara1, stea,stea,stea,stea,stea,stea,stea, bara2);
System.out.printf("%6c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%n",line, line, line, line, line, line, line, line, line, line, line, line, line, line, line, line, line, line);
    System.out.printf("%12c%c%c%c%c%n", linie, linie, linie, linie, linie);
    System.out.printf("%12c%c%c%c%c%n", linie, linie, linie, linie, linie);
    System.out.printf("%12c%c%c%c%c%n", linie, linie, linie, linie, linie);
  }
}